@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "APP_DIR=%SCRIPT_DIR%app"

if not defined PERSODL_HOST set "PERSODL_HOST=127.0.0.1"
if not defined PERSODL_PORT set "PERSODL_PORT=8080"

set "LOG_DIR=%APPDATA%\PersoDL\Logs\21loader"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1
set "LOG_FILE=%LOG_DIR%\server.log"

if not exist "%APP_DIR%\persodl-server.exe" (
  echo Executable not found: "%APP_DIR%\persodl-server.exe"
  exit /b 1
)

pushd "%APP_DIR%" || (
  echo Unable to enter app directory: "%APP_DIR%"
  exit /b 1
)

start "" /B "%APP_DIR%\persodl-server.exe" --host "%PERSODL_HOST%" --port "%PERSODL_PORT%" >> "%LOG_FILE%" 2>&1
timeout /t 1 /nobreak >nul
start "" "http://%PERSODL_HOST%:%PERSODL_PORT%"

popd
endlocal
