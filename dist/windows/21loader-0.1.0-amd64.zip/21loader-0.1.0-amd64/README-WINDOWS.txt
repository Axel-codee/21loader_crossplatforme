21loader - Windows package (amd64)
==================================

Quick start:
1. Double-click 21loader.cmd
2. Browser should open automatically on http://127.0.0.1:8080

Notes:
- Logs: %APPDATA%\PersoDL\Logs\21loader\server.log
- Change host/port before launch (optional):
  set PERSODL_HOST=127.0.0.1
  set PERSODL_PORT=8080
- Keep the app/ folder next to 21loader.cmd
